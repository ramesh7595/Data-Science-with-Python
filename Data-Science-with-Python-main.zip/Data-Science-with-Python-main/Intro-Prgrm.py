# -*- coding: utf-8 -*-
"""
Created on Sun Apr 25 16:45:56 2021

@author: pc
"""

V = [1,2,3,4,5]
print(V)

import matplotlib.pyplot as plt
plt.plot(V)
